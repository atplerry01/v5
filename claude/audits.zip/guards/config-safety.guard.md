# CONFIG SAFETY GUARD

**Status:** ACTIVE
**Severity baseline:** S0/S1 violations FAIL the build.
**Owner:** WBSM v3 structural integrity.

## SCOPE
All files under `src/`, `infrastructure/`. Test fixtures under `tests/` are explicitly out of scope unless they hit production-shared files.

## RULES

### CFG-R1 — No credentials in source-controlled config files (S0)
**Forbidden in `appsettings*.json`, `*.config`, `**/docker-compose*.yml`, `**/*.compose.yml`, `**/compose.yaml`, and any committed config file:**
- Username/Password key-value pairs
- API keys, secret keys, access tokens
- Any string matching `Password=`, `Pwd=`, `SecretKey`, `AccessKey`, `ApiKey`, `Token=`
- Any non-empty value under keys ending in `Password`, `SecretKey`, `AccessKey`
- In docker-compose/compose files: literal `Password=`, `SecretKey:`, `AccessKey:`, `APIKey:`, `Token:` with non-`${...}` right-hand-sides

**Required form for compose files:** `${VAR_NAME}` substitution, with the variable defined in a gitignored `.env.local`.

**Exception:** None. Use environment variables exclusively.

### CFG-R2 — No hardcoded production endpoint defaults in source-controlled config (S1)
Forbidden literal values in `appsettings*.json` for keys representing endpoints (`*ConnectionString`, `*BootstrapServers`, `*Endpoint`, `*Url`, `*Host`, `*Port`):
- `localhost`, `127.0.0.1`, `0.0.0.0`
- Any port literal (`5432`, `6379`, `9092`, `29092`, `8181`, `9000`, etc.)
- Any URL literal

Endpoints MUST be sourced from environment variables at startup. Composition root MUST throw `InvalidOperationException` when missing — no `??` fallback.

### CFG-R3 — No hardcoded fallbacks in C# composition code (S1)
Forbidden pattern in any `.cs` file under `src/`:
```csharp
configuration["X"] ?? "Host=...;Password=..."
configuration.GetValue<string>("X") ?? "literal-default"
```
Required pattern (no-fallback):
```csharp
var value = configuration.GetValue<string>("X")
    ?? throw new InvalidOperationException("X is required");
```

### CFG-R4 — Use IOptions<T> over raw IConfiguration in business code (S2)
Controllers, handlers, services MUST inject strongly-typed `IOptions<TOptions>` (or `IOptionsMonitor<T>`). Direct `IConfiguration` indexer access is restricted to:
- `src/platform/host/composition/**` (composition root)
- `Program.cs`

Magic timeouts/intervals/retry counts in business logic must come from an Options class.

### CFG-R5 — appsettings.json shape
The committed `appsettings.json` MUST contain only:
- Logging configuration
- Feature flags (boolean)
- Domain-shaped constants (e.g., topic names that are part of the schema contract)
- Empty placeholder structure for env-bound keys (or omit them entirely)

## CI ENFORCEMENT
1. **Architecture test:** scan `src/platform/host/appsettings*.json` for `Password=`, `SecretKey`, `AccessKey`, `localhost`, port literals — fail on any hit.
2. **Architecture test:** grep `src/**/*.cs` for `?? "Host=` and `?? "Server=` and `configuration\[` outside composition — fail on any hit.
3. **Build:** composition root must be wired to throw on missing env vars (verified by integration test that boots host with empty environment and asserts `InvalidOperationException`).
4. **Architecture test:** scan `**/docker-compose*.yml`, `**/*.compose.yml`, `**/compose.yaml` for literal `Password=`, `SecretKey:`, `AccessKey:`, `APIKey:`, `Token:` with non-`${...}` values — fail on any hit.

## ALLOWED EXCEPTIONS
- `src/platform/host/composition/observability/ObservabilityComposition.cs` and `InfrastructureComposition.cs` may directly read `IConfiguration` to bootstrap options.
- Health-check timeouts may be hardcoded (not part of operational SLA).
- Domain-shaped Kafka topic constants (e.g., `whyce.operational.sandbox.todo.events`) are schema contracts, not configuration.

## REMEDIATION TEMPLATE
```csharp
// BEFORE
var cs = configuration["EventStore__ConnectionString"]
    ?? "Host=localhost;Username=whyce;Password=whyce";

// AFTER
var cs = configuration.GetValue<string>("EventStore:ConnectionString")
    ?? throw new InvalidOperationException(
        "EVENTSTORE__CONNECTIONSTRING environment variable is required");
```

## NEW RULES INTEGRATED — 2026-04-13 (promoted from new-rules backlog)

- **CFG-R1 Docker Compose Extension** (S0): CFG-R1 file glob extended to include `**/docker-compose*.yml`, `**/*.compose.yml`, `**/compose.yaml`. Forbidden patterns: literal `Password=`, `SecretKey:`, `AccessKey:`, `APIKey:`, `Token:` with non-`${...}` right-hand-sides. Required form: `${VAR_NAME}` substitution with variable defined in gitignored `.env.local`. Source: `20260410-CFG-R1-DOCKER-COMPOSE-SCAN-guards.md`.

## NEW RULES INTEGRATED — 2026-04-10 (promoted from new-rules backlog)

- **CFG-K1 — Configuration key form** (S0): Configuration key lookups MUST use the `Section:Key` form, never `Section__Key`. The double-underscore form is the env-var encoding consumed by `AddEnvironmentVariables()`, which rewrites `Foo__Bar` to config key `Foo:Bar`. A literal `GetValue<string>("Foo__Bar")` lookup therefore never resolves env vars and silently throws (or silently uses a fallback) on every required key. CI grep: `GetValue<.*>\(\"[A-Za-z0-9_]+__` = S0 fail. Originating evidence: 15 broken callsites in `src/platform/host/composition/**` (`InfrastructureComposition.cs`, `ObservabilityComposition.cs`, `TodoBootstrap.cs`) blocking all live execution. Source: `_archives/20260408-145000-validation-live-execution.md` Finding 5.
