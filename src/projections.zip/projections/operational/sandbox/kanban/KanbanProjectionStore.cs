using System.Diagnostics.Metrics;
using System.Text.Json;
using Npgsql;

namespace Whyce.Projections.Operational.Sandbox.Kanban;

/// <summary>
/// Shared persistence layer for all Kanban projection handlers.
/// Owns the instrumented connection, Load, and idempotent Upsert operations
/// against the kanban_read_model table.
/// </summary>
public sealed class KanbanProjectionStore
{
    private const string Schema = "projection_operational_sandbox_kanban";
    private const string Table = "kanban_read_model";
    private const string AggregateType = "Kanban";
    private const string PoolName = "projections";

    private static readonly Meter PoolMeter = new("Whyce.Postgres", "1.0");
    private static readonly Counter<long> PoolAcquisitions =
        PoolMeter.CreateCounter<long>("postgres.pool.acquisitions");
    private static readonly Counter<long> PoolAcquisitionFailures =
        PoolMeter.CreateCounter<long>("postgres.pool.acquisition_failures");

    private readonly NpgsqlDataSource _dataSource;

    public KanbanProjectionStore(NpgsqlDataSource dataSource)
    {
        ArgumentNullException.ThrowIfNull(dataSource);
        _dataSource = dataSource;
    }

    public async Task<KanbanBoardReadModel?> LoadAsync(Guid aggregateId, CancellationToken cancellationToken)
    {
        await using var conn = await OpenInstrumentedAsync();

        await using var cmd = new NpgsqlCommand(
            $"SELECT state FROM {Schema}.{Table} WHERE aggregate_id = @id LIMIT 1", conn);
        cmd.Parameters.AddWithValue("id", aggregateId);

        await using var reader = await cmd.ExecuteReaderAsync(cancellationToken);
        if (!await reader.ReadAsync(cancellationToken)) return null;

        var json = reader.GetString(0);
        return JsonSerializer.Deserialize<KanbanBoardReadModel>(json);
    }

    public async Task UpsertAsync(
        Guid aggregateId,
        KanbanBoardReadModel state,
        string lastEventType,
        Guid eventId,
        Guid correlationId,
        CancellationToken cancellationToken)
    {
        var stateJson = JsonSerializer.Serialize(state);

        await using var conn = await OpenInstrumentedAsync();

        var sql = $"""
            INSERT INTO {Schema}.{Table}
                (aggregate_id, aggregate_type, current_version, state, last_event_id, last_event_type, correlation_id, projected_at, created_at)
            VALUES
                (@aggId, @aggType, 1, @state::jsonb, @lastEventId, @eventType, @corrId, NOW(), NOW())
            ON CONFLICT (aggregate_id) DO UPDATE SET
                current_version = {Schema}.{Table}.current_version + 1,
                state = @state::jsonb,
                last_event_id = @lastEventId,
                last_event_type = @eventType,
                projected_at = NOW()
            WHERE {Schema}.{Table}.last_event_id IS DISTINCT FROM @lastEventId
            """;

        await using var cmd = new NpgsqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("aggId", aggregateId);
        cmd.Parameters.AddWithValue("aggType", AggregateType);
        cmd.Parameters.AddWithValue("state", stateJson);
        cmd.Parameters.AddWithValue("lastEventId", eventId);
        cmd.Parameters.AddWithValue("eventType", lastEventType);
        cmd.Parameters.AddWithValue("corrId", correlationId);

        await cmd.ExecuteNonQueryAsync(cancellationToken);
    }

    private async Task<NpgsqlConnection> OpenInstrumentedAsync()
    {
        try
        {
            var conn = await _dataSource.OpenConnectionAsync();
            PoolAcquisitions.Add(1, new KeyValuePair<string, object?>("pool", PoolName));
            return conn;
        }
        catch (Exception ex)
        {
            PoolAcquisitionFailures.Add(1,
                new KeyValuePair<string, object?>("pool", PoolName),
                new KeyValuePair<string, object?>("reason", ex.GetType().Name));
            throw;
        }
    }
}
