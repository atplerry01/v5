using Whyce.Shared.Contracts.EventFabric;
using Whyce.Shared.Contracts.Events.Operational.Sandbox.Kanban;
using Whyce.Shared.Contracts.Infrastructure.Projection;
using Whyce.Shared.Contracts.Projection;

namespace Whyce.Projections.Operational.Sandbox.Kanban.Card;

/// <summary>
/// Projection handler for card-level events (create, move, reorder, complete, update).
/// Delegates persistence to KanbanProjectionStore.
/// </summary>
public sealed class KanbanCardProjectionHandler :
    IEnvelopeProjectionHandler,
    IProjectionHandler<KanbanCardCreatedEventSchema>,
    IProjectionHandler<KanbanCardMovedEventSchema>,
    IProjectionHandler<KanbanCardReorderedEventSchema>,
    IProjectionHandler<KanbanCardCompletedEventSchema>,
    IProjectionHandler<KanbanCardUpdatedEventSchema>
{
    private readonly KanbanProjectionStore _store;

    public KanbanCardProjectionHandler(KanbanProjectionStore store) => _store = store;

    public ProjectionExecutionPolicy ExecutionPolicy => ProjectionExecutionPolicy.Inline;

    public Task HandleAsync(IEventEnvelope envelope, CancellationToken cancellationToken = default)
    {
        return envelope.Payload switch
        {
            KanbanCardCreatedEventSchema e => HandleCardCreated(e, envelope.EventId, envelope.CorrelationId, cancellationToken),
            KanbanCardMovedEventSchema e => HandleCardMoved(e, envelope.EventId, envelope.CorrelationId, cancellationToken),
            KanbanCardReorderedEventSchema e => HandleCardReordered(e, envelope.EventId, envelope.CorrelationId, cancellationToken),
            KanbanCardCompletedEventSchema e => HandleCardCompleted(e, envelope.EventId, envelope.CorrelationId, cancellationToken),
            KanbanCardUpdatedEventSchema e => HandleCardUpdated(e, envelope.EventId, envelope.CorrelationId, cancellationToken),
            _ => throw new InvalidOperationException(
                $"KanbanCardProjectionHandler received unmatched event: {envelope.Payload.GetType().Name}.")
        };
    }

    // IProjectionHandler<T> typed overloads (called without envelope context)
    public async Task HandleAsync(KanbanCardCreatedEventSchema e, CancellationToken ct = default) => await HandleCardCreated(e, Guid.Empty, Guid.Empty, ct);
    public async Task HandleAsync(KanbanCardMovedEventSchema e, CancellationToken ct = default) => await HandleCardMoved(e, Guid.Empty, Guid.Empty, ct);
    public async Task HandleAsync(KanbanCardReorderedEventSchema e, CancellationToken ct = default) => await HandleCardReordered(e, Guid.Empty, Guid.Empty, ct);
    public async Task HandleAsync(KanbanCardCompletedEventSchema e, CancellationToken ct = default) => await HandleCardCompleted(e, Guid.Empty, Guid.Empty, ct);
    public async Task HandleAsync(KanbanCardUpdatedEventSchema e, CancellationToken ct = default) => await HandleCardUpdated(e, Guid.Empty, Guid.Empty, ct);

    private async Task HandleCardCreated(KanbanCardCreatedEventSchema e, Guid eventId, Guid correlationId, CancellationToken cancellationToken)
    {
        var state = await _store.LoadAsync(e.AggregateId, cancellationToken) ??
                    new KanbanBoardReadModel { BoardId = e.AggregateId };

        var lists = new System.Collections.Generic.List<KanbanListReadModel>(state.Lists);
        var listIndex = lists.FindIndex(l => l.ListId == e.ListId);
        if (listIndex < 0) return;

        var list = lists[listIndex];
        var cards = new System.Collections.Generic.List<KanbanCardReadModel>(list.Cards);
        if (!cards.Exists(c => c.CardId == e.CardId))
        {
            cards.Add(new KanbanCardReadModel
            {
                CardId = e.CardId,
                Title = e.Title,
                Description = e.Description,
                Position = e.Position,
                IsCompleted = false
            });
            cards.Sort((a, b) => a.Position.CompareTo(b.Position));
        }

        lists[listIndex] = list with { Cards = cards };
        state = state with { Lists = lists };
        await _store.UpsertAsync(e.AggregateId, state, "KanbanCardCreatedEvent", eventId, correlationId, cancellationToken);
    }

    private async Task HandleCardMoved(KanbanCardMovedEventSchema e, Guid eventId, Guid correlationId, CancellationToken cancellationToken)
    {
        var state = await _store.LoadAsync(e.AggregateId, cancellationToken);
        if (state is null) return;

        var lists = new System.Collections.Generic.List<KanbanListReadModel>(state.Lists);

        var fromIndex = lists.FindIndex(l => l.ListId == e.FromListId);
        var toIndex = lists.FindIndex(l => l.ListId == e.ToListId);
        if (fromIndex < 0 || toIndex < 0) return;

        var fromCards = new System.Collections.Generic.List<KanbanCardReadModel>(lists[fromIndex].Cards);
        var cardIndex = fromCards.FindIndex(c => c.CardId == e.CardId);
        if (cardIndex < 0) return;

        var card = fromCards[cardIndex] with { Position = e.NewPosition };
        fromCards.RemoveAt(cardIndex);
        lists[fromIndex] = lists[fromIndex] with { Cards = fromCards };

        var toCards = new System.Collections.Generic.List<KanbanCardReadModel>(lists[toIndex].Cards);
        toCards.Add(card);
        toCards.Sort((a, b) => a.Position.CompareTo(b.Position));
        lists[toIndex] = lists[toIndex] with { Cards = toCards };

        state = state with { Lists = lists };
        await _store.UpsertAsync(e.AggregateId, state, "KanbanCardMovedEvent", eventId, correlationId, cancellationToken);
    }

    private async Task HandleCardReordered(KanbanCardReorderedEventSchema e, Guid eventId, Guid correlationId, CancellationToken cancellationToken)
    {
        var state = await _store.LoadAsync(e.AggregateId, cancellationToken);
        if (state is null) return;

        var lists = new System.Collections.Generic.List<KanbanListReadModel>(state.Lists);
        var listIndex = lists.FindIndex(l => l.ListId == e.ListId);
        if (listIndex < 0) return;

        var cards = new System.Collections.Generic.List<KanbanCardReadModel>(lists[listIndex].Cards);
        var cardIndex = cards.FindIndex(c => c.CardId == e.CardId);
        if (cardIndex < 0) return;

        cards[cardIndex] = cards[cardIndex] with { Position = e.NewPosition };
        cards.Sort((a, b) => a.Position.CompareTo(b.Position));
        lists[listIndex] = lists[listIndex] with { Cards = cards };

        state = state with { Lists = lists };
        await _store.UpsertAsync(e.AggregateId, state, "KanbanCardReorderedEvent", eventId, correlationId, cancellationToken);
    }

    private async Task HandleCardCompleted(KanbanCardCompletedEventSchema e, Guid eventId, Guid correlationId, CancellationToken cancellationToken)
    {
        var state = await _store.LoadAsync(e.AggregateId, cancellationToken);
        if (state is null) return;

        var lists = new System.Collections.Generic.List<KanbanListReadModel>(state.Lists);
        for (var i = 0; i < lists.Count; i++)
        {
            var cards = new System.Collections.Generic.List<KanbanCardReadModel>(lists[i].Cards);
            var cardIndex = cards.FindIndex(c => c.CardId == e.CardId);
            if (cardIndex >= 0)
            {
                cards[cardIndex] = cards[cardIndex] with { IsCompleted = true };
                lists[i] = lists[i] with { Cards = cards };
                break;
            }
        }

        state = state with { Lists = lists };
        await _store.UpsertAsync(e.AggregateId, state, "KanbanCardCompletedEvent", eventId, correlationId, cancellationToken);
    }

    private async Task HandleCardUpdated(KanbanCardUpdatedEventSchema e, Guid eventId, Guid correlationId, CancellationToken cancellationToken)
    {
        var state = await _store.LoadAsync(e.AggregateId, cancellationToken);
        if (state is null) return;

        var lists = new System.Collections.Generic.List<KanbanListReadModel>(state.Lists);
        for (var i = 0; i < lists.Count; i++)
        {
            var cards = new System.Collections.Generic.List<KanbanCardReadModel>(lists[i].Cards);
            var cardIndex = cards.FindIndex(c => c.CardId == e.CardId);
            if (cardIndex >= 0)
            {
                cards[cardIndex] = cards[cardIndex] with { Title = e.Title, Description = e.Description };
                lists[i] = lists[i] with { Cards = cards };
                break;
            }
        }

        state = state with { Lists = lists };
        await _store.UpsertAsync(e.AggregateId, state, "KanbanCardUpdatedEvent", eventId, correlationId, cancellationToken);
    }
}
