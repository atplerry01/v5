using Whyce.Shared.Contracts.EventFabric;
using Whyce.Shared.Contracts.Events.Operational.Sandbox.Kanban;
using Whyce.Shared.Contracts.Infrastructure.Projection;
using Whyce.Shared.Contracts.Projection;

namespace Whyce.Projections.Operational.Sandbox.Kanban.List;

/// <summary>
/// Projection handler for list-level events.
/// Delegates persistence to KanbanProjectionStore.
/// </summary>
public sealed class KanbanListProjectionHandler :
    IEnvelopeProjectionHandler,
    IProjectionHandler<KanbanListCreatedEventSchema>
{
    private readonly KanbanProjectionStore _store;

    public KanbanListProjectionHandler(KanbanProjectionStore store) => _store = store;

    public ProjectionExecutionPolicy ExecutionPolicy => ProjectionExecutionPolicy.Inline;

    public Task HandleAsync(IEventEnvelope envelope, CancellationToken cancellationToken = default)
    {
        return envelope.Payload switch
        {
            KanbanListCreatedEventSchema e => HandleAsync(e, envelope.EventId, envelope.CorrelationId, cancellationToken),
            _ => throw new InvalidOperationException(
                $"KanbanListProjectionHandler received unmatched event: {envelope.Payload.GetType().Name}.")
        };
    }

    public async Task HandleAsync(KanbanListCreatedEventSchema e, CancellationToken cancellationToken = default)
        => await HandleAsync(e, Guid.Empty, Guid.Empty, cancellationToken);

    private async Task HandleAsync(KanbanListCreatedEventSchema e, Guid eventId, Guid correlationId, CancellationToken cancellationToken)
    {
        var state = await _store.LoadAsync(e.AggregateId, cancellationToken) ??
                    new KanbanBoardReadModel { BoardId = e.AggregateId };

        var lists = new System.Collections.Generic.List<KanbanListReadModel>(state.Lists);
        if (!lists.Exists(l => l.ListId == e.ListId))
        {
            lists.Add(new KanbanListReadModel
            {
                ListId = e.ListId,
                Name = e.Name,
                Position = e.Position
            });
            lists.Sort((a, b) => a.Position.CompareTo(b.Position));
        }

        state = state with { Lists = lists };
        await _store.UpsertAsync(e.AggregateId, state, "KanbanListCreatedEvent", eventId, correlationId, cancellationToken);
    }
}
