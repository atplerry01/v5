using Whyce.Shared.Contracts.EventFabric;
using Whyce.Shared.Contracts.Events.Operational.Sandbox.Kanban;
using Whyce.Shared.Contracts.Infrastructure.Projection;
using Whyce.Shared.Contracts.Projection;

namespace Whyce.Projections.Operational.Sandbox.Kanban.Board;

/// <summary>
/// Projection handler for board-level events.
/// Delegates persistence to KanbanProjectionStore.
/// </summary>
public sealed class KanbanBoardProjectionHandler :
    IEnvelopeProjectionHandler,
    IProjectionHandler<KanbanBoardCreatedEventSchema>
{
    private readonly KanbanProjectionStore _store;

    public KanbanBoardProjectionHandler(KanbanProjectionStore store) => _store = store;

    public ProjectionExecutionPolicy ExecutionPolicy => ProjectionExecutionPolicy.Inline;

    public Task HandleAsync(IEventEnvelope envelope, CancellationToken cancellationToken = default)
    {
        return envelope.Payload switch
        {
            KanbanBoardCreatedEventSchema e => HandleAsync(e, envelope.EventId, envelope.CorrelationId, cancellationToken),
            _ => throw new InvalidOperationException(
                $"KanbanBoardProjectionHandler received unmatched event: {envelope.Payload.GetType().Name}.")
        };
    }

    public async Task HandleAsync(KanbanBoardCreatedEventSchema e, CancellationToken cancellationToken = default)
        => await HandleAsync(e, Guid.Empty, Guid.Empty, cancellationToken);

    private async Task HandleAsync(KanbanBoardCreatedEventSchema e, Guid eventId, Guid correlationId, CancellationToken cancellationToken)
    {
        var state = await _store.LoadAsync(e.AggregateId, cancellationToken) ??
                    new KanbanBoardReadModel { BoardId = e.AggregateId };
        state = state with { Name = e.Name };
        await _store.UpsertAsync(e.AggregateId, state, "KanbanBoardCreatedEvent", eventId, correlationId, cancellationToken);
    }
}
